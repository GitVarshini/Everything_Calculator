import { useState, useEffect, useMemo } from 'react';
import { Calculator } from '@/types/calculator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Copy, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CalculatorEngineProps {
  calculator: Calculator;
  className?: string;
}

export function CalculatorEngine({ calculator, className }: CalculatorEngineProps) {
  const { toast } = useToast();
  const [values, setValues] = useState<Record<string, number>>({});
  const [copied, setCopied] = useState(false);

  // Initialize values with defaults
  useEffect(() => {
    const initialValues: Record<string, number> = {};
    calculator.inputs.forEach((input) => {
      initialValues[input.name] = input.defaultValue ?? 0;
    });
    setValues(initialValues);
  }, [calculator]);

  const result = useMemo(() => {
    try {
      // Create a safe evaluation context
      const evalContext = { Math, ...values };
      
      // Build the function with all input variables as parameters
      const paramNames = Object.keys(values);
      const paramValues = Object.values(values);
      
      // Create and execute the formula
      const fn = new Function(...paramNames, `return ${calculator.formula}`);
      const result = fn(...paramValues);
      
      if (typeof result === 'number' && !isNaN(result) && isFinite(result)) {
        return Math.round(result * 100) / 100;
      }
      return null;
    } catch (error) {
      console.error('Calculation error:', error);
      return null;
    }
  }, [values, calculator.formula]);

  const handleInputChange = (name: string, value: string) => {
    const numValue = parseFloat(value) || 0;
    setValues((prev) => ({ ...prev, [name]: numValue }));
  };

  const handleCopyResult = async () => {
    if (result === null) return;
    
    try {
      await navigator.clipboard.writeText(result.toString());
      setCopied(true);
      toast({
        title: 'Copied!',
        description: 'Result copied to clipboard',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: 'Copy failed',
        description: 'Failed to copy to clipboard',
        variant: 'destructive',
      });
    }
  };

  return (
    <Card className={`shadow-card border-0 ${className}`}>
      <CardHeader className="pb-4">
        <CardTitle className="text-2xl text-foreground">{calculator.title}</CardTitle>
        {calculator.description && (
          <CardDescription className="text-muted-foreground">
            {calculator.description}
          </CardDescription>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Input fields */}
        <div className="grid gap-4 sm:grid-cols-2">
          {calculator.inputs.map((input) => (
            <div key={input.name} className="space-y-2">
              <Label htmlFor={input.name} className="text-sm font-medium text-foreground">
                {input.label}
              </Label>
              <Input
                id={input.name}
                type="number"
                placeholder={input.placeholder}
                value={values[input.name] ?? ''}
                onChange={(e) => handleInputChange(input.name, e.target.value)}
                className="bg-muted/50 border-border focus:border-primary transition-colors"
              />
            </div>
          ))}
        </div>

        {/* Result display */}
        <div className="pt-4 border-t border-border">
          <div className="flex items-center justify-between p-4 rounded-lg gradient-primary">
            <div>
              <p className="text-sm font-medium text-primary-foreground/80">
                {calculator.outputLabel || 'Result'}
              </p>
              <p className="text-3xl font-bold text-primary-foreground">
                {result !== null ? result.toLocaleString() : '—'}
              </p>
            </div>
            <Button
              size="icon"
              variant="ghost"
              onClick={handleCopyResult}
              disabled={result === null}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
