import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Calculator, CalculatorInput } from '@/types/calculator';
import { useToast } from '@/hooks/use-toast';
import { Json } from '@/integrations/supabase/types';

export function useCalculators() {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const generateCalculator = async (prompt: string): Promise<Calculator | null> => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-calculator', {
        body: { prompt },
      });

      if (error) {
        throw new Error(error.message);
      }

      if (data.error) {
        throw new Error(data.error);
      }

      return data as Calculator;
    } catch (error) {
      console.error('Error generating calculator:', error);
      toast({
        title: 'Generation failed',
        description: error instanceof Error ? error.message : 'Failed to generate calculator',
        variant: 'destructive',
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const saveCalculator = async (calculator: Calculator, authorInfo?: { name?: string; email?: string }): Promise<string | null> => {
    try {
      const { data, error } = await supabase
        .from('calculators')
        .insert({
          title: calculator.title,
          description: calculator.description,
          inputs: calculator.inputs as unknown as Json,
          formula: calculator.formula,
          output_label: calculator.outputLabel,
          author_name: authorInfo?.name,
          author_email: authorInfo?.email,
        })
        .select('id')
        .single();

      if (error) throw error;

      toast({
        title: 'Calculator saved!',
        description: 'Your calculator is now in the marketplace.',
      });

      return data.id;
    } catch (error) {
      console.error('Error saving calculator:', error);
      toast({
        title: 'Save failed',
        description: 'Failed to save calculator',
        variant: 'destructive',
      });
      return null;
    }
  };

  const fetchCalculators = async (sortBy: 'newest' | 'popular' | 'rating' = 'newest', search?: string) => {
    let query = supabase.from('calculators').select('*');

    if (search) {
      query = query.ilike('title', `%${search}%`);
    }

    switch (sortBy) {
      case 'popular':
        query = query.order('view_count', { ascending: false });
        break;
      case 'rating':
        query = query.order('view_count', { ascending: false });
        break;
      default:
        query = query.order('created_at', { ascending: false });
    }

    const { data, error } = await query.limit(50);

    if (error) {
      console.error('Error fetching calculators:', error);
      return [];
    }

    return data.map((row) => ({
      id: row.id,
      title: row.title,
      description: row.description,
      inputs: (row.inputs as unknown as CalculatorInput[]) || [],
      formula: row.formula,
      outputLabel: row.output_label,
      authorName: row.author_name,
      viewCount: row.view_count,
      createdAt: row.created_at,
    })) as Calculator[];
  };

  const fetchCalculatorById = async (id: string): Promise<Calculator | null> => {
    const { data, error } = await supabase
      .from('calculators')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error || !data) {
      console.error('Error fetching calculator:', error);
      return null;
    }

    // Increment view count
    await supabase
      .from('calculators')
      .update({ view_count: (data.view_count || 0) + 1 })
      .eq('id', id);

    return {
      id: data.id,
      title: data.title,
      description: data.description,
      inputs: (data.inputs as unknown as CalculatorInput[]) || [],
      formula: data.formula,
      outputLabel: data.output_label,
      authorName: data.author_name,
      viewCount: data.view_count,
      createdAt: data.created_at,
    };
  };

  const rateCalculator = async (calculatorId: string, rating: number) => {
    try {
      const { error } = await supabase
        .from('calculator_ratings')
        .insert({
          calculator_id: calculatorId,
          rating,
        });

      if (error) throw error;

      toast({
        title: 'Thanks for rating!',
        description: 'Your rating has been recorded.',
      });

      return true;
    } catch (error) {
      console.error('Error rating calculator:', error);
      toast({
        title: 'Rating failed',
        description: 'Failed to submit rating',
        variant: 'destructive',
      });
      return false;
    }
  };

  const getAverageRating = async (calculatorId: string) => {
    const { data, error } = await supabase
      .from('calculator_ratings')
      .select('rating')
      .eq('calculator_id', calculatorId);

    if (error || !data || data.length === 0) {
      return { average: 0, count: 0 };
    }

    const sum = data.reduce((acc, curr) => acc + curr.rating, 0);
    return {
      average: Math.round((sum / data.length) * 10) / 10,
      count: data.length,
    };
  };

  return {
    isLoading,
    generateCalculator,
    saveCalculator,
    fetchCalculators,
    fetchCalculatorById,
    rateCalculator,
    getAverageRating,
  };
}
