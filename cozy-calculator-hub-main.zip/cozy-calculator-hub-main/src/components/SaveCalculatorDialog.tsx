import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

interface SaveCalculatorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (authorInfo: { name?: string; email?: string }) => Promise<void>;
  isLoading?: boolean;
}

export function SaveCalculatorDialog({ open, onOpenChange, onSave, isLoading }: SaveCalculatorDialogProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSave = async () => {
    await onSave({
      name: name.trim() || undefined,
      email: email.trim() || undefined,
    });
    setName('');
    setEmail('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Save to Marketplace</DialogTitle>
          <DialogDescription>
            Share your calculator with the community. Attribution is optional.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="author-name">Your name (optional)</Label>
            <Input
              id="author-name"
              placeholder="Anonymous"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="author-email">Email (optional, not displayed)</Label>
            <Input
              id="author-email"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isLoading} className="gradient-primary">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Calculator'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
