export interface CalculatorInput {
  name: string;
  label: string;
  type: 'number';
  placeholder?: string;
  defaultValue?: number;
}

export interface Calculator {
  id?: string;
  title: string;
  description?: string;
  inputs: CalculatorInput[];
  formula: string;
  outputLabel?: string;
  authorName?: string;
  authorEmail?: string;
  viewCount?: number;
  averageRating?: number;
  ratingCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface CalculatorRating {
  id: string;
  calculatorId: string;
  rating: number;
  createdAt: string;
}
