import { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { CalculatorCard } from '@/components/CalculatorCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useCalculators } from '@/hooks/useCalculators';
import { Calculator } from '@/types/calculator';
import { Search, TrendingUp, Clock, Loader2 } from 'lucide-react';

type SortOption = 'newest' | 'popular' | 'rating';

const Browse = () => {
  const { fetchCalculators } = useCalculators();
  const [calculators, setCalculators] = useState<Calculator[]>([]);
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadCalculators();
  }, [sortBy]);

  const loadCalculators = async (searchTerm?: string) => {
    setIsLoading(true);
    const data = await fetchCalculators(sortBy, searchTerm);
    setCalculators(data);
    setIsLoading(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadCalculators(search);
  };

  const sortOptions: { value: SortOption; label: string; icon: typeof Clock }[] = [
    { value: 'newest', label: 'Newest', icon: Clock },
    { value: 'popular', label: 'Popular', icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">
            Calculator Marketplace
          </h1>
          <p className="text-muted-foreground">
            Browse community-created calculators or search for exactly what you need.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <form onSubmit={handleSearch} className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search calculators..."
              className="pl-10 h-11"
            />
          </form>
          
          <div className="flex gap-2">
            {sortOptions.map((option) => {
              const Icon = option.icon;
              const isActive = sortBy === option.value;
              
              return (
                <Button
                  key={option.value}
                  variant={isActive ? 'secondary' : 'outline'}
                  onClick={() => setSortBy(option.value)}
                  className="gap-2"
                >
                  <Icon className="h-4 w-4" />
                  {option.label}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Calculator Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : calculators.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {calculators.map((calc) => (
              <CalculatorCard key={calc.id} calculator={calc} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-muted/30 rounded-2xl">
            <p className="text-xl text-muted-foreground mb-2">No calculators found</p>
            <p className="text-muted-foreground">
              {search ? 'Try a different search term' : 'Be the first to create one!'}
            </p>
          </div>
        )}
      </main>
    </div>
  );
};

export default Browse;
