import { Calculator } from '@/types/calculator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Eye, Calculator as CalcIcon, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';

interface CalculatorCardProps {
  calculator: Calculator;
}

export function CalculatorCard({ calculator }: CalculatorCardProps) {
  return (
    <Link to={`/calculator/${calculator.id}`}>
      <Card className="h-full border-0 shadow-card hover:shadow-hover transition-all duration-300 cursor-pointer group animate-fade-in">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg gradient-secondary">
                <CalcIcon className="h-4 w-4 text-secondary-foreground" />
              </div>
              <CardTitle className="text-lg group-hover:text-primary transition-colors line-clamp-1">
                {calculator.title}
              </CardTitle>
            </div>
          </div>
          {calculator.description && (
            <CardDescription className="line-clamp-2 mt-2">
              {calculator.description}
            </CardDescription>
          )}
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                {calculator.viewCount || 0}
              </span>
              {calculator.authorName && (
                <span className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  {calculator.authorName}
                </span>
              )}
            </div>
            {calculator.createdAt && (
              <span className="text-xs">
                {formatDistanceToNow(new Date(calculator.createdAt), { addSuffix: true })}
              </span>
            )}
          </div>
          <div className="mt-3 flex gap-1 flex-wrap">
            {calculator.inputs.slice(0, 3).map((input) => (
              <Badge key={input.name} variant="secondary" className="text-xs">
                {input.label}
              </Badge>
            ))}
            {calculator.inputs.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{calculator.inputs.length - 3} more
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
