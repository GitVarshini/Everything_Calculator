import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Header } from '@/components/Header';
import { CalculatorEngine } from '@/components/CalculatorEngine';
import { StarRating } from '@/components/StarRating';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useCalculators } from '@/hooks/useCalculators';
import { Calculator } from '@/types/calculator';
import { ArrowLeft, Eye, User, Calendar } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const CalculatorPage = () => {
  const { id } = useParams<{ id: string }>();
  const { fetchCalculatorById, rateCalculator, getAverageRating } = useCalculators();
  const [calculator, setCalculator] = useState<Calculator | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [rating, setRating] = useState({ average: 0, count: 0 });
  const [hasRated, setHasRated] = useState(false);

  useEffect(() => {
    if (id) {
      loadCalculator(id);
    }
  }, [id]);

  const loadCalculator = async (calcId: string) => {
    setIsLoading(true);
    const [calc, ratingData] = await Promise.all([
      fetchCalculatorById(calcId),
      getAverageRating(calcId),
    ]);
    setCalculator(calc);
    setRating(ratingData);
    setIsLoading(false);
  };

  const handleRate = async (value: number) => {
    if (!id || hasRated) return;
    
    const success = await rateCalculator(id, value);
    if (success) {
      setHasRated(true);
      // Refresh rating
      const newRating = await getAverageRating(id);
      setRating(newRating);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-8 max-w-3xl">
          <Skeleton className="h-10 w-32 mb-6" />
          <Skeleton className="h-96 w-full rounded-xl" />
        </main>
      </div>
    );
  }

  if (!calculator) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-8 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Calculator not found</h1>
          <Link to="/browse">
            <Button>Browse calculators</Button>
          </Link>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 max-w-3xl">
        <Link to="/browse">
          <Button variant="ghost" className="mb-6 -ml-2">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to browse
          </Button>
        </Link>

        <CalculatorEngine calculator={calculator} className="mb-8" />

        {/* Meta info and rating */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-muted/30 rounded-lg">
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Eye className="h-4 w-4" />
              {calculator.viewCount || 0} views
            </span>
            {calculator.authorName && (
              <span className="flex items-center gap-1">
                <User className="h-4 w-4" />
                {calculator.authorName}
              </span>
            )}
            {calculator.createdAt && (
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {formatDistanceToNow(new Date(calculator.createdAt), { addSuffix: true })}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm font-medium text-foreground">
                {rating.average > 0 ? `${rating.average}/5` : 'No ratings'}
              </p>
              <p className="text-xs text-muted-foreground">
                {rating.count} {rating.count === 1 ? 'rating' : 'ratings'}
              </p>
            </div>
            <StarRating
              rating={hasRated ? 0 : rating.average}
              onRate={hasRated ? undefined : handleRate}
              readonly={hasRated}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default CalculatorPage;
