import { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { PromptInput } from '@/components/PromptInput';
import { CalculatorEngine } from '@/components/CalculatorEngine';
import { CalculatorCard } from '@/components/CalculatorCard';
import { SaveCalculatorDialog } from '@/components/SaveCalculatorDialog';
import { Button } from '@/components/ui/button';
import { useCalculators } from '@/hooks/useCalculators';
import { Calculator } from '@/types/calculator';
import { Save, RotateCcw, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Index = () => {
  const { isLoading, generateCalculator, saveCalculator, fetchCalculators } = useCalculators();
  const [generatedCalculator, setGeneratedCalculator] = useState<Calculator | null>(null);
  const [featuredCalculators, setFeaturedCalculators] = useState<Calculator[]>([]);
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchCalculators('popular').then(setFeaturedCalculators);
  }, []);

  const handleGenerate = async (prompt: string) => {
    const calculator = await generateCalculator(prompt);
    if (calculator) {
      setGeneratedCalculator(calculator);
    }
  };

  const handleSave = async (authorInfo: { name?: string; email?: string }) => {
    if (!generatedCalculator) return;
    
    setIsSaving(true);
    const id = await saveCalculator(generatedCalculator, authorInfo);
    setIsSaving(false);
    
    if (id) {
      setSaveDialogOpen(false);
      // Refresh featured calculators
      fetchCalculators('popular').then(setFeaturedCalculators);
    }
  };

  const handleReset = () => {
    setGeneratedCalculator(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 md:py-12">
        {/* Hero Section */}
        <section className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-foreground mb-4 animate-fade-in">
            Create Any Calculator
            <span className="block gradient-primary bg-clip-text text-transparent mt-2">
              Instantly
            </span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 animate-fade-in">
            Describe the calculator you need in plain English. Our AI generates it for you in seconds.
          </p>
          
          <PromptInput
            onSubmit={handleGenerate}
            isLoading={isLoading}
            placeholder="e.g., mortgage payment calculator, BMI calculator, tip splitter..."
            className="max-w-3xl mx-auto animate-fade-in"
          />
        </section>

        {/* Generated Calculator */}
        {generatedCalculator && (
          <section className="mb-16 animate-scale-in">
            <div className="max-w-2xl mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-foreground">Your Calculator</h2>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleReset}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    New
                  </Button>
                  <Button size="sm" onClick={() => setSaveDialogOpen(true)} className="gradient-primary">
                    <Save className="h-4 w-4 mr-2" />
                    Save to Marketplace
                  </Button>
                </div>
              </div>
              <CalculatorEngine calculator={generatedCalculator} />
            </div>
          </section>
        )}

        {/* Featured Calculators */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-display font-bold text-foreground">
              Popular Calculators
            </h2>
            <Link to="/browse">
              <Button variant="ghost" className="gap-2">
                Browse all
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          {featuredCalculators.length > 0 ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {featuredCalculators.slice(0, 8).map((calc) => (
                <CalculatorCard key={calc.id} calculator={calc} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-muted/30 rounded-2xl">
              <p className="text-muted-foreground">
                No calculators yet. Be the first to create one!
              </p>
            </div>
          )}
        </section>
      </main>

      <SaveCalculatorDialog
        open={saveDialogOpen}
        onOpenChange={setSaveDialogOpen}
        onSave={handleSave}
        isLoading={isSaving}
      />
    </div>
  );
};

export default Index;
